# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['jsonlogging']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'jsonlogging',
    'version': '0.1.0',
    'description': "Provides a JSONFormatter object that can be used by Python's logging module's Handler objects to log messages in JSON format.",
    'long_description': None,
    'author': 'Danila Kritsky',
    'author_email': 'danilakritsky@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
